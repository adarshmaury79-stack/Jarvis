package com.adarsh.jarvis

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.ServiceCompat
import java.util.Locale

class JarvisService : Service() {
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var engine: Engine
    private val h = Handler(Looper.getMainLooper())
    private var cmd = false
    private var on = false
    private val wake = Regex("(jar|jer|gar|har|dar)v[iy]s|jarwis")
    private val again = Runnable { listen() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "jarvis"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(ch, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch).setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis active").setContentText("Bolo: Hey Jarvis").setContentIntent(pi).build()
        ServiceCompat.startForeground(this, 1, n, if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
        if (!on) {
            on = true
            val t = TextToSpeech(this) { st -> if (st == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) {}
                override fun onError(u: String?) { h.post { next(500) } }
                override fun onDone(u: String?) { h.post { next(400) } }
            })
            tts = t
            engine = Engine(this) { say(it) }
            Bus.set("STANDBY"); listen()
        }
        return START_STICKY
    }

    private fun say(t: String) {
        Bus.log("Jarvis: $t"); Bus.set("SPEAKING")
        h.removeCallbacks(again); sr?.cancel()
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j")
        h.postDelayed(again, 9000)
    }

    private fun next(ms: Long) {
        if (!on) return
        Bus.set(if (cmd) "LISTENING" else "STANDBY")
        h.removeCallbacks(again); h.postDelayed(again, ms)
    }

    private fun got(t: String) {
        val n = norm(t)
        if (cmd) { cmd = false; Bus.log("Aap: $t"); engine.handle(t); return }
        val m = wake.find(n) ?: run { next(200); return }
        val rest = n.substring(m.range.last + 1).trim(' ', ',')
        Bus.log("Aap: $t")
        if (rest.length > 2) engine.handle(rest) else { cmd = true; say("Ji, boliye.") }
    }

    private fun listen() {
        if (!on) return
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this); sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) next(300) else got(t)
            }
            override fun onError(e: Int) { cmd = false; next(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400) }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        })
    }

    override fun onDestroy() {
        on = false; h.removeCallbacksAndMessages(null)
        sr?.destroy(); tts?.shutdown()
        Bus.set("OFF"); super.onDestroy()
    }
}
