package com.adarsh.jarvis

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Engine(private val ctx: Context, private val say: (String) -> Unit) {
    private fun bg(f: () -> Unit) { Thread { try { f() } catch (e: Exception) {} }.start() }
    private fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
    private fun acc() = JarvisAccess.inst

    private fun waitClick(vararg l: String, ms: Long = 9000): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (acc()?.click(*l) == true) return true
            Thread.sleep(500)
        }
        return false
    }

    private fun phone(name: String): String? {
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null
        ) ?: return null
        c.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun wa(num: String): String {
        val d = num.filter { it.isDigit() }
        return if (d.length == 10) "91$d" else d
    }

    fun handle(raw: String) {
        val q = raw.lowercase(Locale.ROOT).replace("jarvis", "").trim()
        val needsAcc = Regex("whatsapp|youtube|insta|speaker|handsfree|hands free").containsMatchIn(q)
        if (needsAcc && acc() == null && !q.contains("kya aaya")) say("Pehle Accessibility on karo, tabhi main tap aur type kar paunga.")

        // Creator
        if (Regex("kisne banaya|who made|who created|creator|tumhe kisne|aapko kisne|banane wala").containsMatchIn(q)) {
            say("Mujhe Adarsh Maurya ne banaya hai."); return
        }
        if (q.contains("adarsh") && (q.contains("insta") || q.contains("account"))) {
            say("Adarsh Maurya ka Instagram khol raha hoon.")
            go(Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/adarsh_maury79")).setPackage("com.instagram.android")); return
        }

        // WhatsApp: read
        if (q.contains("whatsapp") && Regex("kya aaya|kisne msg|kya msg|padho|message aaya").containsMatchIn(q)) {
            val h = JarvisNotif.history
            say(if (h.isEmpty()) "Koi naya WhatsApp message nahi mila." else h.takeLast(3).joinToString(". ")); return
        }
        // WhatsApp: reply
        Regex("(?:whatsapp\\s+)?(?:uska\\s+)?(?:reply|jawab)\\s*(?:karo|do|de do)?\\s*(.+)").find(q)?.takeIf { q.contains("reply") || q.contains("jawab") }?.let {
            val m = it.groupValues[1].replace("whatsapp", "").trim()
            say(if (JarvisNotif.reply(ctx, m)) "${JarvisNotif.sender ?: "Unko"} ko reply bhej diya: $m" else "Reply nahi bhej paya. Pehle koi WhatsApp message aana chahiye aur Notification access on hona chahiye."); return
        }
        // WhatsApp: send
        val ws = Regex("whatsapp\\s+(?:par\\s+|pe\\s+)?(.+?)\\s+ko\\s+(.+?)(?:\\s+(?:bhejo|bhej do|send karo|send|likho))?$").find(q)
            ?: Regex("(.+?)\\s+ko\\s+whatsapp\\s+(?:par\\s+|pe\\s+)?(.+?)(?:\\s+(?:bhejo|bhej do|send karo|send|likho))?$").find(q)
        if (ws != null) {
            val name = ws.groupValues[1]; val msg = ws.groupValues[2]
            val n = phone(name) ?: run { say("$name naam ka contact nahi mila."); return }
            say("$name ko WhatsApp par bhej raha hoon.")
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${wa(n)}?text=" + Uri.encode(msg))).setPackage("com.whatsapp"))
            bg { Thread.sleep(2500); waitClick("Send", "भेजें") }
            return
        }

        // Call
        Regex("(.+?)\\s+ko\\s+(?:call|phone|fone|kol)").find(q)?.let {
            val name = it.groupValues[1].replace("handsfree", "").replace("hands free", "").trim()
            val n = phone(name) ?: run { say("$name naam ka contact nahi mila."); return }
            say("$name ko call laga raha hoon.")
            try { go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + n.filter { c -> c.isDigit() || c == '+' }))) }
            catch (e: SecurityException) { say("Call ki permission do."); return }
            if (Regex("handsfree|hands free|speaker").containsMatchIn(q)) bg { Thread.sleep(3500); waitClick("Speaker", "स्पीकर", ms = 10000) }
            return
        }

        // YouTube
        if (q.contains("youtube") || q.contains("you tube")) {
            val song = Regex("(?:youtube|you tube).*?(?:par|pe|per|mein)\\s+(.+?)\\s*(?:chala|play|laga|bajao|chalao)").find(q)?.groupValues?.get(1)
            val like = q.contains("like"); val sub = q.contains("subscribe")
            val cm = Regex("comment\\s+(?:karo\\s+)?(.+)$").find(q)?.groupValues?.get(1)
            if (song == null) { say("YouTube khol raha hoon."); go(ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube") ?: return); return }
            say("YouTube par $song chala raha hoon.")
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(song))).setPackage("com.google.android.youtube"))
            bg {
                Thread.sleep(4500); acc()?.tap(0.5f, 0.30f); Thread.sleep(5000)
                if (like) waitClick("like this video", "Like")
                if (sub) waitClick("Subscribe")
                if (cm != null) {
                    waitClick("Comments", "Add a comment"); Thread.sleep(2000)
                    waitClick("Add a comment"); Thread.sleep(1000)
                    acc()?.type(cm); Thread.sleep(800)
                    waitClick("Send", "Post comment", "Comment")
                }
            }
            return
        }

        // Instagram: user search -> first post -> comment
        Regex("insta\\w*\\s+(?:par\\s+|pe\\s+)?(.+?)\\s+search.*?post\\s+(?:par|pe)\\s+(.+?)(?:\\s+(?:comment|msg|message).*)?$").find(q)?.let {
            val user = it.groupValues[1].replace(" ", ""); val msg = it.groupValues[2]
            say("Instagram par $user khol raha hoon aur pehli post par comment kar raha hoon.")
            go(Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/$user")).setPackage("com.instagram.android"))
            bg {
                Thread.sleep(4500)
                if (acc()?.click("Photo by", "Reel by", "Post by") != true) acc()?.tap(0.17f, 0.72f)
                Thread.sleep(3000)
                waitClick("Comment", "Add a comment"); Thread.sleep(2000)
                acc()?.type(msg); Thread.sleep(800)
                waitClick("Post", "Send")
            }
            return
        }

        // Utilities
        if (Regex("time|samay|waqt|baje").containsMatchIn(q)) { say("Abhi " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + " ho rahe hain."); return }
        if (Regex("date|tarikh|aaj kya din").containsMatchIn(q)) { say("Aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + " hai."); return }
        if (Regex("tumhara naam|aapka naam|kaun ho|who are you").containsMatchIn(q)) { say("Main Jarvis hoon, Adarsh Maurya ka banaya hua voice assistant."); return }

        // Open any app
        Regex("(.+?)\\s+(?:kholo|khol do|open)").find(q)?.let {
            val n = it.groupValues[1].replace("open", "").trim()
            val pm = ctx.packageManager
            val app = pm.getInstalledApplications(0).firstOrNull { a -> pm.getApplicationLabel(a).toString().contains(n, true) }
            val li = app?.let { a -> pm.getLaunchIntentForPackage(a.packageName) }
            if (li != null) { say("$n khol raha hoon."); go(li) } else say("$n app nahi mila.")
            return
        }
        say("Mujhe samajh nahi aaya. Dobara bolo.")
    }
}
