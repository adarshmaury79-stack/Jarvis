package com.adarsh.jarvis

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotif : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        val e = sbn.notification.extras
        val title = e.getString(Notification.EXTRA_TITLE) ?: return
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        if (title == "WhatsApp") return
        val act = sbn.notification.actions?.firstOrNull { it.remoteInputs != null && it.remoteInputs.isNotEmpty() }
        if (act != null) action = act
        sender = title
        history.add("$title ne kaha: $text")
        while (history.size > 5) history.removeAt(0)
    }

    companion object {
        var sender: String? = null
        var action: Notification.Action? = null
        val history = ArrayList<String>()

        fun reply(ctx: Context, text: String): Boolean {
            val a = action ?: return false
            val ri = a.remoteInputs ?: return false
            val i = Intent(); val b = Bundle()
            b.putCharSequence(ri[0].resultKey, text)
            RemoteInput.addResultsToIntent(ri, i, b)
            return try { a.actionIntent.send(ctx, 0, i); true } catch (e: Exception) { false }
        }
    }
}
