package com.adarsh.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils

class HudView(c: Context) : View(c) {
    var state = "OFF"
        set(v) { field = v; invalidate() }
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 9000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy) * 0.94f
        val col = when (state) { "LISTENING" -> 0xFF00FFA3.toInt(); "SPEAKING" -> 0xFFFFB300.toInt(); "STANDBY" -> 0xFF00E5FF.toInt(); else -> 0xFF3A4B5C.toInt() }
        val spd = if (state == "LISTENING") 8.0 else 3.0
        val pulse = (Math.sin(Math.toRadians(t * spd)) * 0.5 + 0.5).toFloat()
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 0.6f, intArrayOf(ColorUtils.setAlphaComponent(col, (70 + pulse * 130).toInt()), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 0.6f, p); p.shader = null
        p.style = Paint.Style.STROKE; p.color = col
        p.strokeWidth = 4f; c.drawCircle(cx, cy, r * (0.20f + 0.05f * pulse), p)
        fun ring(rad: Float, w: Float, start: Float, sweep: Float, n: Int) {
            p.strokeWidth = w
            val rect = RectF(cx - rad, cy - rad, cx + rad, cy + rad)
            for (i in 0 until n) c.drawArc(rect, start + i * 360f / n, sweep, false, p)
        }
        ring(r * 0.40f, 3f, t * 2, 70f, 3)
        ring(r * 0.58f, 6f, -t * 1.5f, 100f, 2)
        ring(r * 0.76f, 2f, t, 25f, 8)
        ring(r * 0.94f, 3f, -t * 0.7f, 60f, 4)
        p.strokeWidth = 2f; p.color = ColorUtils.setAlphaComponent(col, 120)
        c.save(); c.rotate(t * 0.5f, cx, cy)
        for (i in 0 until 60) { c.drawLine(cx, cy - r * 0.86f, cx, cy - r * (if (i % 5 == 0) 0.81f else 0.84f), p); c.rotate(6f, cx, cy) }
        c.restore()
    }
}
