package com.adarsh.jarvis

object Bus {
    var state = "OFF"
    val lines = ArrayList<String>()
    var onLog: ((String) -> Unit)? = null
    var onState: ((String) -> Unit)? = null
    fun log(s: String) { lines.add(s); while (lines.size > 30) lines.removeAt(0); onLog?.invoke(s) }
    fun set(s: String) { state = s; onState?.invoke(s) }
}
