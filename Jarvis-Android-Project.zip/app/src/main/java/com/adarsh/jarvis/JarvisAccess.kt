package com.adarsh.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccess : AccessibilityService() {
    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { inst = null; super.onDestroy() }

    private fun walk(n: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out.add(n)
        for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, out) }
    }

    fun click(vararg labels: String): Boolean {
        val r = rootInActiveWindow ?: return false
        val all = ArrayList<AccessibilityNodeInfo>(); walk(r, all)
        for (lb in labels) for (n in all) {
            val t = n.text?.toString() ?: ""
            val d = n.contentDescription?.toString() ?: ""
            if (t.contains(lb, true) || d.contains(lb, true)) {
                var c: AccessibilityNodeInfo? = n
                while (c != null && !c.isClickable) c = c.parent
                if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
        }
        return false
    }

    fun type(text: String): Boolean {
        val r = rootInActiveWindow ?: return false
        val all = ArrayList<AccessibilityNodeInfo>(); walk(r, all)
        val f = all.firstOrNull { it.isEditable && it.isFocused } ?: all.firstOrNull { it.isEditable } ?: return false
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun tap(fx: Float, fy: Float) {
        val m = resources.displayMetrics
        val p = Path().apply { moveTo(m.widthPixels * fx, m.heightPixels * fy) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        dispatchGesture(g, null, null)
    }

    companion object { var inst: JarvisAccess? = null }
}
