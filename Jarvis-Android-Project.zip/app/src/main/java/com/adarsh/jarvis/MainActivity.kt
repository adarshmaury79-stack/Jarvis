package com.adarsh.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var hud: HudView
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var btn: Button
    private val rows = ArrayList<Triple<TextView, String, () -> Boolean>>()
    private val cyan = 0xFF00E5FF.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(color: Int, rad: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(rad).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun tv(t: String, size: Float, color: Int, gravity: Int = Gravity.CENTER, face: Typeface = Typeface.DEFAULT) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color); this.gravity = gravity; typeface = face }

    private fun accOn() = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
    private fun micOn() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun batOn() = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF020B14.toInt(); window.navigationBarColor = 0xFF020B14.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(36), dp(20), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF020B14.toInt(), 0xFF07223A.toInt()))
        }
        root.addView(tv("J.A.R.V.I.S", 28f, cyan, face = Typeface.create("sans-serif-light", Typeface.NORMAL)).apply { letterSpacing = 0.35f })
        root.addView(tv("Just A Rather Very Intelligent System", 12f, 0xFF7FA6B8.toInt()))
        hud = HudView(this)
        root.addView(hud, LinearLayout.LayoutParams(-1, dp(290)).apply { topMargin = dp(12) })
        status = tv("", 14f, cyan, face = Typeface.MONOSPACE)
        root.addView(status)
        btn = Button(this).apply {
            textSize = 16f; setTextColor(0xFF020B14.toInt()); background = box(cyan, 28); isAllCaps = false
            setOnClickListener { toggle() }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(14) })

        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = box(0x33102A40, 16, 0x5500E5FF); setPadding(dp(16), dp(10), dp(16), dp(10)) }
        fun row(label: String, key: String, ok: () -> Boolean, open: () -> Unit) {
            val t = tv("", 14f, 0xFFD8F3FF.toInt(), Gravity.START).apply { setPadding(0, dp(7), 0, dp(7)); setOnClickListener { open() } }
            rows.add(Triple(t, label, ok)); card.addView(t)
        }
        row("Microphone", "mic", { micOn() }) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, "android.permission.POST_NOTIFICATIONS"), 1) }
        row("Accessibility Service", "acc", { accOn() }) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        row("Notification Access", "not", { NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName) }) { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        row("Display over other apps", "ovl", { Settings.canDrawOverlays(this) }) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        row("Battery Optimization Off", "bat", { batOn() }) { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        log = tv("", 12f, 0xFFA9D6E5.toInt(), Gravity.START, Typeface.MONOSPACE).apply { background = box(0x33000000, 12); setPadding(dp(12), dp(10), dp(12), dp(10)); minLines = 5 }
        root.addView(log, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        root.addView(tv("Created by Adarsh Maurya", 12f, 0xFF7FA6B8.toInt()).apply { setPadding(0, dp(16), 0, 0) })
        root.addView(tv("@adarsh_maury79", 13f, cyan).apply { setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/adarsh_maury79"))) } })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        if (!micOn()) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, "android.permission.POST_NOTIFICATIONS"), 1)
    }

    private fun toggle() {
        if (Bus.state == "OFF") {
            if (!micOn()) { status.text = "Grant microphone permission first"; return }
            ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
        } else stopService(Intent(this, JarvisService::class.java))
    }

    private fun render() {
        hud.state = Bus.state
        status.text = when (Bus.state) {
            "STANDBY" -> "● STANDBY  —  say \"Hey Jarvis\""
            "LISTENING" -> "● LISTENING  —  speak your command"
            "SPEAKING" -> "● SPEAKING"
            else -> "○ OFFLINE"
        }
        btn.text = if (Bus.state == "OFF") "ACTIVATE JARVIS" else "DEACTIVATE"
        log.text = Bus.lines.takeLast(7).joinToString("\n").ifEmpty { "Try: \"Hey Jarvis, open Instagram\"" }
        for ((t, label, ok) in rows) {
            val good = ok()
            t.text = if (good) "✔  $label" else "✖  $label  (tap to enable)"
            t.setTextColor(if (good) 0xFF00FFA3.toInt() else 0xFFFF6B6B.toInt())
        }
    }

    override fun onResume() {
        super.onResume()
        Bus.onState = { runOnUiThread { render() } }
        Bus.onLog = { runOnUiThread { render() } }
        render()
    }

    override fun onPause() { Bus.onState = null; Bus.onLog = null; super.onPause() }
}
