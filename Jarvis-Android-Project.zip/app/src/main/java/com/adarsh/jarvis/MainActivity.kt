package com.adarsh.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var tts: TextToSpeech
    private lateinit var engine: Engine
    private var sr: SpeechRecognizer? = null

    private fun say(t: String) {
        runOnUiThread { log.append("\nJarvis: $t\n") }
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j")
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }
        engine = Engine(this) { say(it) }
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS), 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF04121C.toInt()); setPadding(40, 80, 40, 40) }
        fun tv(t: String, s: Float, c: Int = 0xFFD8F3FF.toInt()) = TextView(this).apply { text = t; textSize = s; setTextColor(c); gravity = Gravity.CENTER }
        root.addView(tv("JARVIS", 28f))
        root.addView(tv("Banaya: Adarsh Maurya", 14f, 0xFF7FA6B8.toInt()))
        val mic = Button(this).apply { text = "🎤  Bolo"; textSize = 22f; setOnClickListener { listen() } }
        root.addView(mic, LinearLayout.LayoutParams(-1, 220).apply { topMargin = 40 })
        root.addView(Button(this).apply { text = "1) Accessibility ON karo"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text = "2) Notification access ON karo"; setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } })
        log = tv("Example: \"WhatsApp Ravi ko kal milte hain bhejo\"", 15f).apply { gravity = Gravity.START }
        root.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 30 })
        root.addView(tv("Instagram: @adarsh_maury79", 14f, 0xFF27D3FF.toInt()).apply {
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/adarsh_maury79"))) }
        })
        setContentView(root)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("Is phone mein speech recognition nahi hai. Google app update karo."); return }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    runOnUiThread { log.append("\nAap: $t\n") }
                    engine.handle(t)
                }
                override fun onError(e: Int) { say("Sun nahi paya, dobara bolo.") }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            })
        }
    }
}
