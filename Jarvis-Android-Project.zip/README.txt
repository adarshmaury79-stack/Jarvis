JARVIS - Banaya: Adarsh Maurya (@adarsh_maury79)

BUILD (APK banane ke liye):
1. Android Studio install karo, File > Open > is Jarvis folder ko chuno. Gradle sync hone do.
2. Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk
3. APK phone mein install karo (Unknown sources allow karo).

PEHLI BAAR SETUP (app ke andar):
- Mic, Call, Contacts permission Allow karo.
- "Accessibility ON karo" > Jarvis > ON.
- "Notification access ON karo" > Jarvis > ON.
- Android 13+: Settings > Apps > Jarvis > 3 dots > "Allow restricted settings", phir Accessibility ON karo.

VOICE COMMANDS:
- WhatsApp Ravi ko kal milte hain bhejo
- WhatsApp par kya aaya
- Reply karo theek hai
- Mummy ko call karo handsfree
- YouTube par Tum Hi Ho chalao like karo subscribe karo comment nice song
- Instagram par virat.kohli search karke pehli post par nice pic comment
- Chrome kholo / Camera kholo
- Tumhe kisne banaya  -> "Adarsh Maurya ne"
- Adarsh ka insta   -> @adarsh_maury79 khulta hai
